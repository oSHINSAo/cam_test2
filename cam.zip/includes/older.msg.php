<div class="capa animated"></div>
<!-- Small modal -->
<div class="modal older18" tabindex="-1" role="dialog" data-keyboard="false" data-backdrop="static">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			
			<div class="modal-header">
				<h1 class="modal-title textCenter">WARNING</h1>
			</div>
			
			<div class="modal-body">
				<hgroup>
					<h3>Content for adults only</h3>
					<h3 class="right">+18</h3>
				</hgroup>
				
				<div class="row">
					<div class="textCenter div1">
						<h4>Sexually explicit content</h4>
					</div>

					<div class="div2">
						<p>This website provides access to material, information, opinion, content, and commentary that includes user generated sexually explicit material (collectively, the "Sexually Explicit Material"). Everyone accessing this site must be at least 18 years of age OR the age of majority in each authority in which you will or may view the Sexually Explicit Material, whichever is higher (the "Age of Majority"). You may not enter this site if Sexually Explicit Material offends you or if the viewing of Sexually Explicit Material is not legal in each community in which you choose to access it via this website.</p>
						<p>Permission to enter this website and to access content provided through it is strictly limited to consenting adults who affirm under unsworn penalties of perjury under title 28 U.S.C. § 1746 and other applicable statutes and laws that the following statements are all true:</p>
						<p>
							<ul>
								<li>I am an ADULT who has reached the Age of Majority in my jurisdiction and where I am choosing to view the Sexually Explicit Material accessed via this website;</li>
								<li>I desire to receive/view Sexually Explicit Material and I believe that sexual acts between consenting adults are neither offensive nor obscene;</li>
								<li>I will not expose minors or anyone who may be offended to the Sexually Explicit Material and agree to be liable for damages and indemnify this site including attorney’s fees and costs;</li>
								<li>I am voluntarily choosing to view and access the content for my own personal use and not on behalf of any government;</li>
								<li>I have determined that viewing, reading, hearing and downloading of Sexually Explicit Material does not violate the standards of any community, town, city, county, state, province or country where I will be accessing the Sexually Explicit Materials;</li>
								<li>I will not inform minors of the existence of this site and will not share content of this site with any minor agree to be liable for damages and indemnify this site including attorney’s fees and costs;</li>
								<li>I am solely responsible for any false disclosures or legal ramifications of viewing, reading or downloading any material appearing on this site and I understand that providing a false declaration under the penalties of perjury is a criminal offense;</li>
								<li>I agree that neither this website nor its affiliates will be held responsible for any legal ramifications arising from any fraudulent entry into or use of this website;</li>
								<li>By clicking the enter button on this website I understand and agree that my entry into and use of this website is governed by the site's Terms and Conditions and I agree to be bound by them and that is my electronic signature and assent to such Terms and Conditions.</li>
								<li>The videos, pictures and dialogue found on this site are user generated and are intended to be used by consenting adults as sexual aids, to provide sexual education, discourse and commentary and to provide sexual entertainment;</li>
								<li>I agree that this Warning and Affirmation constitutes a legally binding agreement between me and the website and is governed by the Electronic Signatures in Global and National Commerce Act (commonly known as the "E-Sign Act"), 15 U.S.C. § 7000, et seq., By choosing to click below and enter the site, I am indicating my agreement to be bound by the above and the Terms and Conditions of the site and I affirmatively adopt the signature line below as my signature and the manifestation of my consent.</li>
							</ul>
						</p>
					</div>
				</div>

			</div>
			<div class="div3 textCenter">
				<a class="btn btn-enter">Sure! Show me some pussy</a>
				<a href='//www.google.com/#q=why+do+I+have+no+friends%3F' class="btn btn-default">Fuck it! I'm out</a>
			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function () { 
		$('.older18').modal('show');
		$('.btn-enter').click(function() {
			$('.older18').modal('hide');
			$('.capa').addClass('slideOutDown');
			$.cookie('older18', '1');
		});

		// $(".modelID-rate").rateYo({
		// 	rating: 3,
		// 	halfStar: true,
		// 	starWidth: "15px",
		// 	ratedFill: "#cf0286",
		// 	normalFill: "#fbfbfb",
		// 	starSvg: '<svg class="shadow" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z"/></svg>'
		// });
	});
</script>